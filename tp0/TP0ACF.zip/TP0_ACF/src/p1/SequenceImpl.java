package p1;

import java.util.Arrays;
import java.util.List;

import test0.Sequence;

public class SequenceImpl implements Sequence{



/**
 * @param l1
 * @param l2
 * @return true if list t1 is a sublist of list t2, where at most one element of t1 may not occur in t2
 */

	public boolean subSeq(Object[] t1, Object[] t2) {
		//TODO: program this function
		
		return true;
		
	} 


}
