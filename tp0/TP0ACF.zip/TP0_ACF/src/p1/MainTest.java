package p1;


import static org.junit.Assert.*;
import org.junit.Test;
import test0.Sequence;


public class MainTest {
	Sequence s= new SequenceImpl();
	
	@Test
	public void test1() {
		Integer[] t1 = new Integer[] { 1, 2, 3 };
		Integer[] t2 = new Integer[] { 1, 2, 3, 4};
		
		assertTrue(s.subSeq(t1,t2));
	}

	// A COMPLETER!!!
}
